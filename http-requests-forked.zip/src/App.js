import React, { useState, useEffect, useCallback } from "react";

import MoviesList from "./components/MoviesList";
import AddMovie from "./components/AddMovie";
import "./App.css";
import useHttp from "./hooks/use-http";

function App() {
  const [movies, setMovies] = useState([]);
  const [movie, setMovie] = useState(null);

  const transformMovies = (moviesObj) => {
    const loadedMovies = [];

    for (const key in moviesObj) {
      loadedMovies.push({
        id: key,
        title: moviesObj[key].title,
        openingText: moviesObj[key].openingText,
        releaseDate: moviesObj[key].releaseDate
      });
    }

    setMovies(loadedMovies);
  };
  const { isLoading, error, fetchMoviesHandler: fetchMovies } = useHttp(
    {
      url: "https://react-http-5af7d-default-rtdb.firebaseio.com/movies.json",
      method: "GET"
    },
    transformMovies
  );

  useEffect(() => {
    fetchMovies();
  }, []);

  const { fetchMoviesHandler: addMovieHandler } = useHttp({
    url: "https://react-http-5af7d-default-rtdb.firebaseio.com/movies.json",
    method: "POST",
    body: movie
  });

  // async function addMovieHandler(movie) {
  //   const response = await fetch(
  //     "https://react-http-5af7d-default-rtdb.firebaseio.com/movies.json",
  //     {
  //       method: "POST",
  //       body: JSON.stringify(movie),
  //       headers: {
  //         "Content-Type": "application/json"
  //       }
  //     }
  //   );
  //   const data = await response.json();
  //   console.log(data);
  // }

  let content = <p>Found no movies.</p>;

  if (movies.length > 0) {
    content = <MoviesList movies={movies} />;
  }

  if (error) {
    content = <p>{error}</p>;
  }

  if (isLoading) {
    content = <p>Loading...</p>;
  }

  const handleAddMovie = (movie) => {
    setMovie(movie);
    addMovieHandler();
  };

  return (
    <React.Fragment>
      <section>
        <AddMovie onAddMovie={handleAddMovie} />
      </section>
      <section>
        <button onClick={fetchMovies}>Fetch Movies</button>
      </section>
      <section>{content}</section>
    </React.Fragment>
  );
}

export default App;
